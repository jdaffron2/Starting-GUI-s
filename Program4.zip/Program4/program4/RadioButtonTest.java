package program4;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class RadioButtonTest extends JFrame
{
  private Container cp;
  private String names[] = {"Bird", "Pig", "Cat", "Dog", "Rabbit"};
  private JRadioButton radiobuttonsarray[];
  private JCheckBox check[];
  private JButton buttons[];
  private JLabel lbl[];
  private JTextField textfields[];
  private JLabel picture;

  public RadioButtonTest()
  {

  }

  public RadioButtonTest(String title)
  {
    super(title);
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    //Setting Grid Layout
    cp = this.getContentPane();
    cp.setLayout(new BorderLayout(5,5));
    JPanel radiobuttons1 = new JPanel(new GridLayout(5,1));
    JPanel radiobuttons2 = new JPanel(new GridLayout(5,1));
    JPanel flow = new JPanel(new FlowLayout(FlowLayout.CENTER,5,5));
    JPanel south = new JPanel(new GridLayout(3,1));
    //Setting arrays to new
    radiobuttonsarray = new JRadioButton[5];
    check = new JCheckBox[5];
    buttons = new JButton[3];
    lbl = new JLabel[3];
    textfields = new JTextField[3];
    //Finds the picture of Bird
    picture = new JLabel(new ImageIcon("./program4/" + names[0]+".gif","Bird"), JLabel.CENTER);

    

    Font font = new Font("Serif", Font.BOLD, 12);
    flow.add(picture);
    flow.add(radiobuttons1);
    flow.add(radiobuttons2);

    cp.add(flow,BorderLayout.NORTH);
    cp.add(south,BorderLayout.SOUTH);

    ButtonGroup buttongroup = new ButtonGroup();
    for(int i = 0; i < names.length; i++)
    {
      radiobuttonsarray[i] = new JRadioButton(names[i]);
      buttongroup.add(radiobuttonsarray[i]);
      radiobuttons1.add(radiobuttonsarray[i]);

      
      check[i] = new JCheckBox(names[i]);
      radiobuttons2.add(check[i]);
    }
    
   
    
    for(int j = 0; j < 3; j++)
    {
      textfields[j] = new JTextField("TextField", 12);
      textfields[j].setFont(font);
      buttons[j] = new JButton("Button " + j);
      buttons[j].setFont(font);
      lbl[j] = new JLabel("Label " + j, JLabel.RIGHT);
    }

    for(int j = 0; j < 3; j++)
    {
      JPanel entiresouth = new JPanel();

      entiresouth.add(lbl[j]);
      entiresouth.add(buttons[j]);
      entiresouth.add(textfields[j]);

      south.add(entiresouth);
    }


    setSize(400,300);
    setVisible(true);


  }
  
  

  public JRadioButton getRadioButtonAt(int index)
  {
    return(radiobuttonsarray[index]);
  }

  public JCheckBox getCheckBoxAt(int index)
  {
    return(check[index]);
  }

 public JButton getButtonAt(int index)
  {
    return(buttons[index]);
  }

  public JLabel getLabelAt(int index)
  {
    return(lbl[index]);
  }

  public JTextField getTextAt(int index)
  {
    return(textfields[index]);
  }


 public JLabel getImage()
  {
    return(picture);
  }

  public static void main(String[] args)
  {
    RadioButtonTest radiobuttontest = new RadioButtonTest("Test");
  }
}