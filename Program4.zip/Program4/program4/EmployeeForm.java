
//Taylor Heatherly
package program4;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class EmployeeForm extends JFrame
{
	
private static final long serialVersionUID = 1L;	

public String title;
public String[] labels;
public int[] no_of_columns;

public EmployeeForm(String title, String[] labels, int[] no_of_columns) 
{
	
super(title);

this.setDefaultCloseOperation(EXIT_ON_CLOSE);

this.setSize(515,290);

JMenuBar menu = new JMenuBar();
setJMenuBar(menu);

JMenu file = new JMenu("File");
menu.add(file);

JMenu edit = new JMenu("Edit");
menu.add(edit);

JMenu search = new JMenu("Search");
menu.add(search);

JMenuItem New = new JMenuItem ("New");
JMenuItem Save = new JMenuItem("Save");
JMenuItem Exit = new JMenuItem ("Exit");

file.add(New);
file.add(Save);
file.add(Exit);

file.setMnemonic(KeyEvent.VK_ALT);
Save.setMnemonic(KeyEvent.VK_S);
KeyStroke altS = KeyStroke.getKeyStroke("alt S");
Save.setAccelerator(altS);


getContentPane().setLayout(new FlowLayout(FlowLayout.CENTER));
JPanel left = new JPanel();
JPanel right = new JPanel();

for(int i = 0; i < labels.length; i++)
{
	
JLabel label = new JLabel(labels[i]);

JTextField textField = new JTextField(no_of_columns[i]);

JPanel labelPanel = new JPanel();

labelPanel.add(label);

labelPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));

left.add(labelPanel);

JPanel textPanel = new JPanel();

textPanel.add(textField);

textPanel.setLayout(new FlowLayout(FlowLayout.LEFT));

right.add(textPanel);

}

   left.setLayout(new GridLayout(labels.length, 1, 0 ,3));
   right.setLayout(new GridLayout(labels.length, 1));
     
   getContentPane().add(left);
   getContentPane().add(right);
     
   JPanel buttonPanel = new JPanel();
     
   JButton Submit = new JButton("Submit");
   JButton Get = new JButton("Get");
     
   buttonPanel.add(Submit);
   buttonPanel.add(Get);
     
   getContentPane().add(buttonPanel);

   this.setVisible(true);
}
public static void main(String[] args) 
{
	
int[] no_of_columns = new int[]{7,20,20,10,20,20};

String[] labels = {"ID","Last Name","First Name","Phone",
                "Department Name", "Job Title"};

EmployeeForm employeeform = new EmployeeForm("Employee Form", labels, no_of_columns);

}

}